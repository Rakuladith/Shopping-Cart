package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		user.setId("US120");
		user.setName("USName120");
		user.setPassword("USPassword");
		user.setEmail("USEmail");
		user.setAddress("USAddress");
		userDAO.saveOrUpdate(user);

/*		
		if(userDAO.get("sdfsf") == null)
		{
			System.out.println("User does not exist");
		}
		else
		{
			System.out.println("User exist... The Details are...");
			System.out.println();
		}

*/
//		userDAO.delete("CG120");
		
		
	}

}

/*
 select * from User
 */

