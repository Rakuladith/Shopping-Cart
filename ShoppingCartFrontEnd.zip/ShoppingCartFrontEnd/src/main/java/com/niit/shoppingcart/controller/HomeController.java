package com.niit.shoppingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	

	@RequestMapping("/")
	public ModelAndView Home(){
		ModelAndView mv  = new ModelAndView("/Home");
	
		return mv;
	}
	
	
	@RequestMapping("/registerHere")
	public ModelAndView registerHere(){
		ModelAndView mv  = new ModelAndView("/Register");
	//mv.addObject("message", "you are successfully registered");
		return mv;
		
	}
	
	@RequestMapping("/loginHere")
	public ModelAndView Login(){
		ModelAndView mv  = new ModelAndView("/Login");
	//mv.addObject("message", "you are successfully registered");
		return mv;
		
	}

}
